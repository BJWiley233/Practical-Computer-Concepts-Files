USE donations;

SELECT 
    donor_first,
    donor_last,
    donation_description,
    donation_value,
    donation_date,
    agency_name
FROM
    donor d
        JOIN
    donation dn ON d.donor_id = dn.donor_id
        JOIN
    agency a ON dn.agency_id = a.agency_id
WHERE
    donation_description = 'Cash'
ORDER BY donor_last ASC;

