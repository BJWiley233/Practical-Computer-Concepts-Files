USE donations;

SELECT 
    donor_id, donor_first, donor_last
FROM
    donor
WHERE
    donor_id NOT IN (SELECT 
            dn.donor_id
        FROM
            donation dn);