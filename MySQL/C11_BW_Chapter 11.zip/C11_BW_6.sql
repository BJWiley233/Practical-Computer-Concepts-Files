USE donations;

SELECT 
    donor_first,
    donor_last,
    donation_desc,
    donation_value,
    CONCAT('$ ', FORMAT(.9 * donation_value, 2)) AS actual_value
FROM
    donor d
        JOIN
    donation dn ON d.donor_id = dn.donor_id
WHERE
    dn.pickup_req = 1