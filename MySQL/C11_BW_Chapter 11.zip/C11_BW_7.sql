USE donations;

SELECT 
    donor_first,
    donor_last,
    SUM(donation_value) AS total_donations,
    MAX(donation_value) AS largest_donation,
    ROUND(AVG(donation_value), 2) AS avg_donation
FROM
    donor d
        JOIN
    donation dn ON d.donor_id = dn.donor_id
GROUP BY donor_first , donor_last ASC WITH ROLLUP;