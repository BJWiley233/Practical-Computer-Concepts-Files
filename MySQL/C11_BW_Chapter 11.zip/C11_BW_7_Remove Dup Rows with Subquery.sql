USE donations;

SELECT 
    IFNULL(first_name, 'Total') 'donor_first',
    IF(ISNULL(last_name) + ISNULL(first_name) = 2,
        'Total',
        IF(ISNULL(last_name) + ISNULL(first_name) = 1,
            'Remove',
            last_name)) 'donor_last',
    total_donations 'Total',
    largest_donation 'Largest',
    avg_donation 'Average'
FROM
    (SELECT 
        donor_first AS first_name,
            donor_last AS last_name,
            SUM(donation_value) AS total_donations,
            MAX(donation_value) AS largest_donation,
            ROUND(AVG(donation_value), 2) AS avg_donation
    FROM
        donor d
    JOIN donation dn ON d.donor_id = dn.donor_id
    GROUP BY donor_first , donor_last ASC WITH ROLLUP) Roll
WHERE
    IF(ISNULL(last_name) + ISNULL(first_name) = 2,
        'Total',
        IF(ISNULL(last_name) + ISNULL(first_name) = 1,
            'Remove',
            last_name)) NOT LIKE 'Remove';


# Another way would be to concat names for full name and remove rows like this
SELECT 
    CONCAT(IFNULL(first_name, 'Total'),
            ' ',
            IF(ISNULL(last_name) + ISNULL(first_name) = 2,
                '',
                IF(ISNULL(last_name) + ISNULL(first_name) = 1,
                    'Remove',
                    last_name))) 'Full_Name',
    total_donations 'Total',
    largest_donation 'Largest',
    avg_donation 'Average'
FROM
    (SELECT 
        donor_first AS first_name,
            donor_last AS last_name,
            SUM(donation_value) AS total_donations,
            MAX(donation_value) AS largest_donation,
            ROUND(AVG(donation_value), 2) AS avg_donation
    FROM
        donor d
    JOIN donation dn ON d.donor_id = dn.donor_id
    GROUP BY donor_first , donor_last ASC WITH ROLLUP) Roll
WHERE
    CONCAT(IFNULL(first_name, 'Total'),
            ' ',
            IF(ISNULL(last_name) + ISNULL(first_name) = 2,
                '',
                IF(ISNULL(last_name) + ISNULL(first_name) = 1,
                    'Remove',
                    last_name))) NOT LIKE '%Remove%';
