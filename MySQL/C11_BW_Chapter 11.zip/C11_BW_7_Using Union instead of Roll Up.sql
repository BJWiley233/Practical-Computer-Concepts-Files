USE donations;

SELECT 
    CONCAT(donor_first, ' ', donor_last) AS full_name,
    SUM(donation_value) AS total_donations,
    MAX(donation_value) AS largest_donation,
    ROUND(AVG(donation_value), 2) AS avg_donation
FROM
    donor d
        JOIN
    donation dn ON d.donor_id = dn.donor_id
GROUP BY full_name ASC 
UNION ALL SELECT 
    'Total',
    SUM(donation_value) AS total_donations,
    MAX(donation_value) AS largest_donation,
    ROUND(AVG(donation_value), 2) AS avg_donation
FROM
    donor d
        JOIN
    donation dn ON d.donor_id = dn.donor_id;