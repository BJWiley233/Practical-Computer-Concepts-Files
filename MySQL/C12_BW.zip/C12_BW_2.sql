USE cf;

CREATE OR REPLACE VIEW labor_pricing AS
    SELECT 
        s.service_id,
        service_date,
        service_desc,
        labor_hours,
        labor_cost,
        round(labor_hours * labor_cost, 2) AS labor_price
    FROM
        service s;

SELECT * from labor_pricing;