USE cf;

CREATE OR REPLACE VIEW service_subtotal AS
    SELECT 
        l.service_id,
        l.service_date,
        l.service_desc,
        SUM(tot_parts_price) AS tot_parts_cost
    FROM
        labor_pricing l
            JOIN
        parts_pricing p ON l.service_id = p.service_id
    GROUP BY service_id

