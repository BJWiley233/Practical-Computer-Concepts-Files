USE cf;

CREATE OR REPLACE VIEW service_billing AS
    SELECT 
        s.service_id,
        fleet_make,
        fleet_model,
        s.service_date,
        s.service_desc,
        CAST(tot_parts_cost AS DECIMAL (9 , 2 )) AS tot_parts_cost,
        CAST(labor_price AS DECIMAL (9 , 2 )) AS labor_price,
        CAST(tot_parts_cost + labor_price AS DECIMAL (9 , 2 )) AS tot_billing
    FROM
        service_subtotal s
            JOIN
        parts_pricing p ON s.service_id = p.service_id
            JOIN
        labor_pricing l ON p.service_id = l.service_id
	GROUP BY s.service_id;

SELECT * FROM service_billing;