USE cf;

CREATE OR REPLACE VIEW inventory_update AS
    SELECT 
        p.part_id,
        part_name,
        part_inventory,
        SUM(parts_qty) AS qty_used,
        IFNULL(part_inventory - SUM(parts_qty),
                part_inventory) AS new_inventory
    FROM
        parts_service ps
            RIGHT JOIN
        parts p ON ps.part_id = p.part_id
    GROUP BY p.part_id
    ORDER BY p.part_id;