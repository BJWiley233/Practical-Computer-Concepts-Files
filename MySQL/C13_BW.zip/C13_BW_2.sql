USE ap; 
DELIMITER // 
 
DROP PROCEDURE IF EXISTS ch13_2// 
CREATE PROCEDURE ch13_2() 
BEGIN 
DECLARE sum_inv_total DECIMAL(9,2);
DECLARE inv_count INT;
DECLARE vend_id INT;
SET vend_id = 123;

SELECT 
    SUM(invoice_total), COUNT(invoice_id)
FROM
    invoices
WHERE
    vendor_id = vend_id INTO sum_inv_total , inv_count;

SELECT 
    CONCAT('$', sum_inv_total) AS TotalInvoiceAmt,
    inv_count AS InvoiceCount;
END// 
 
Call ch13_2(); 