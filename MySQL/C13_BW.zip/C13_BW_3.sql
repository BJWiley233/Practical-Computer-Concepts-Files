USE ap; 
DELIMITER // 
 
DROP PROCEDURE IF EXISTS ch13_3// 
CREATE PROCEDURE ch13_3() 
BEGIN 
DECLARE first_date DATE DEFAULT '2014-05-01';
DECLARE second_date DATE DEFAULT '2014-05-30';
DECLARE inv_amount INT DEFAULT 150;

SELECT 
    vendor_name, invoice_date, invoice_number, invoice_total
FROM
    vendors v
        JOIN
    invoices i ON v.vendor_id = i.vendor_id
WHERE
    invoice_date BETWEEN first_date AND second_date
        AND invoice_total > inv_amount;
END// 
 
Call ch13_3(); 
