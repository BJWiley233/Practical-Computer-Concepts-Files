USE ap; 
DELIMITER // 
 
DROP PROCEDURE IF EXISTS ch13_4// 
CREATE PROCEDURE ch13_4() 
BEGIN
DECLARE tot_due DECIMAL(9,2);

SELECT 
    SUM(invoice_total - payment_total - credit_total) AS total
FROM
    invoices INTO tot_due;

IF tot_due > 50000 THEN
	SELECT 'High invoice balance detected' AS high_balance;
ELSEIF  tot_due  between 30000 AND 50000 THEN
	SELECT 'Substantial invoice balance detected' AS substantial_balance;
ELSEIF  tot_due  between 20000 AND 30000 THEN
	SELECT 'Manageable invoice balance detected' AS manageable_balance;
ELSE 
	SELECT 'Low invoice balance due' AS low_balance;
END IF;
END//

CALL ch13_4;