USE ap; 
DELIMITER // 
 
DROP PROCEDURE IF EXISTS ch13_5// 
CREATE PROCEDURE ch13_5(inv_id INT) 
BEGIN
DECLARE v_state VARCHAR(2); 
DECLARE v_city VARCHAR(30);
#DECLARE inv_id INT;
#SET inv_id = 10;

SELECT vendor_state, vendor_city
FROM vendors v JOIN invoices i
	ON v.vendor_id = i.vendor_id
WHERE invoice_id = inv_id
INTO v_state, v_city;

CASE 
	WHEN v_state = 'AZ' THEN
		SELECT 'Arizona vendor' AS vendor_area_state;
	WHEN v_state = 'CA' THEN
		IF v_city = 'Fresno' THEN
			SELECT 'Fresno California vendor' AS vendor_area_state;
		ELSEIF v_city = 'Oxnard' THEN
			SELECT 'LA Metro California vendor' AS vendor_area_state; 
		ELSE 
			SELECT 'California' AS vendor_area_state; 
		END IF;
	ELSE 
		SELECT 'National vendor' AS vendor_area_state;
END Case;
END//

CALL ch13_5(15);
CALL ch13_5(46);
CALL ch13_5(12);
CALL ch13_5(10);


# I decided to try this below for fun.  Would probably be inefficient with large values since 
# it takes in a string which has to concat the vendor ids first.  I could create a sub function
# to do this maybe next week.  I want to learn how to eventually create a function / group of
# functions that reads in an CSV with a list of IDs inserts into a temporary table
#and then returns a CSV of associated selected data on and with those IDs.
USE ap; 
DELIMITER // 
 
DROP PROCEDURE IF EXISTS test// 
CREATE PROCEDURE test(IN numberArray VARCHAR(100)) 
BEGIN
DECLARE test_count INT;
DECLARE i INT Default 1;
DECLARE v_state VARCHAR(2); 
DECLARE v_city VARCHAR(30);
DECLARE inv_id INT;

SET test_count = LENGTH(numberArray) - LENGTH(REPLACE(numberArray, ',', '')) + 1;

While i < test_count + 1 DO
	SELECT invoice_id FROM invoices
	WHERE invoice_id = substring_index(substring_index(numberArray, ',', i), ',', -1)
	INTO inv_id;
	
    SELECT vendor_state, vendor_city
	FROM vendors v JOIN invoices i
	ON v.vendor_id = i.vendor_id
	WHERE invoice_id = inv_id
	INTO v_state, v_city;
    
    CASE 
	WHEN v_state = 'AZ' THEN
		SELECT 'Arizona vendor' AS vendor_area_state;
	WHEN v_state = 'CA' THEN
		IF v_city = 'Fresno' THEN
			SELECT 'Fresno California vendor' AS vendor_area_state;
		ELSEIF v_city = 'Oxnard' THEN
			SELECT 'LA Metro California vendor' AS vendor_area_state; 
		ELSE 
			SELECT 'California' AS vendor_area_state; 
		END IF;
	ELSE 
		SELECT 'National vendor' AS vendor_area_state;
	END Case;

	SET i = i + 1;
    
END While;

END//

# call manually to invoice ids
CALL test('15, 46, 12, 10');


# here I just need to create a function that reads the CSV into table values
# and then call the concatenation into the main procedure

DROP TEMPORARY TABLE IF EXISTS test_table;
CREATE TEMPORARY TABLE test_table (element INT);
INSERT INTO test_table (element) VALUES (15), (46), (12), (10);


#### WHOOOOHOOO!!!!! This WORKS!!!!!!!!!
SELECT GROUP_CONCAT(element SEPARATOR ', ') INTO @result FROM test_table;
CALL test(@result);