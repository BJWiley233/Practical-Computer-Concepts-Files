/*
Write a script that creates and calls a stored procedure named ch13_6. This
procedure will return a representation of an 8 bit binary number that looks like
this:
*/

DROP PROCEDURE IF EXISTS eight_bit;
DELIMITER //
CREATE PROCEDURE eight_bit(number_ int)

BEGIN
Declare i int default number_;
Declare loop_string varchar(100);
Declare full_string varchar(10000) default "";

WHILE i > 0 DO
	SET loop_string = CONCAT('Position ', i, ' = ', Power(2,i-1), ' | ');
    SET full_string = CONCAT(full_string, loop_string);
    SET i = i - 1;
END While;

SELECT full_string;
End//

CALL eight_bit(8);
CALL eight_bit(16);