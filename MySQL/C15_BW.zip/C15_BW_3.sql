USE ap; 
CREATE TABLE invoice2 
SELECT * FROM Invoices;

DROP PROCEDURE IF EXISTS cred_update;

DELIMITER //

CREATE PROCEDURE cred_update()
BEGIN

DECLARE c_update DECIMAL(9,2);

SELECT AVG(credit_total) FROM invoice2 INTO c_update;

WHILE c_update < 100 DO
	UPDATE invoice2
    SET credit_total = credit_total + .75;
    SELECT AVG(credit_total) FROM invoice2 INTO c_update;
END WHILE;

END//

USE ap; 
SELECT * FROM invoice2; 
SELECT AVG(credit_total) FROM invoice2; 
CALL cred_update(); 
SELECT * FROM invoice2; 
SELECT AVG(credit_total) FROM invoice2; 