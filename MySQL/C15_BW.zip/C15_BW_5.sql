Use ap;

DROP FUNCTION IF EXISTS get_invoice_total;

DELIMITER //

CREATE FUNCTION get_invoice_total(vendor_id_input INT (100))
RETURNS DECIMAL(9,2)
BEGIN
DECLARE total_amount DECIMAL(9,2);
SELECT 
    SUM(invoice_total) AS total_invoices
FROM
    invoices
WHERE
    vendor_id = vendor_id_input INTO total_amount;
RETURN(total_amount);

END//

SELECT GET_INVOICE_TOTAL(122) AS total_invoices;




