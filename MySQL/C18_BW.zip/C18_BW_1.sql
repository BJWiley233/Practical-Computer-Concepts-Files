GRANT USAGE
ON *.* 
TO db_champ IDENTIFIED BY '1234';

## The user does not have access to any databases.  Just to access and login to the connection.
