RENAME USER db_champ TO db_user;

GRANT ALL PRIVILEGES ON *.* TO db_user IDENTIFIED BY '1234';

REVOKE GRANT OPTION ON *.* FROM db_user;

## You must over over the connection under the home screen, left click and then click edit connection
## and then you must also change the name to the new user name in order to use the same connection.