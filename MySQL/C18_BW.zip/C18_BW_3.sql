CREATE USER ap_selector IDENTIFIED BY 'br*a*';

GRANT SELECT 
ON ap.*
TO ap_selector;