ALTER USER db_user IDENTIFIED BY '1mTh38est';
ALTER USER ap_selector IDENTIFIED BY '6Run7W0rK';
SET PASSWORD FOR ap_invoice_clerk = '5k1Mmin6OffTh370P';