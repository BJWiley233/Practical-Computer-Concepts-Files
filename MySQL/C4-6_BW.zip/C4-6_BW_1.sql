USE ap;

SELECT 
    vendor_name,
    vendor_city,
    vendor_state,
    invoice_number,
    invoice_date,
    invoice_total
FROM
    vendors v
        JOIN
    invoices i ON v.vendor_id = i.vendor_id
WHERE
    invoice_total > 500
        AND invoice_date BETWEEN '2014-06-01' AND '2014-06-30'
ORDER BY vendor_name ASC , invoice_total DESC;