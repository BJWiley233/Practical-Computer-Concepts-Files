USE ap;

SELECT 
    COUNT(DISTINCT v.vendor_id) AS total,
    'Active Accounts' AS `status`
FROM
    vendors v
        JOIN
    invoices i ON v.vendor_id = i.vendor_id 
UNION SELECT 
    COUNT(DISTINCT v.vendor_id) AS total,
    'Inactive Accounts' AS `status`
FROM
    vendors v
        LEFT JOIN
    invoices i ON v.vendor_id = i.vendor_id
WHERE
    i.vendor_id IS NULL;