USE ap;

SELECT 
    vendor_name,
    i.invoice_id,
    invoice_date,
    invoice_total,
    line_item_amount,
    account_description,
    vendor_state
FROM
    vendors v,
    invoices i,
    invoice_line_items il,
    general_ledger_accounts g
WHERE
    v.vendor_id = i.vendor_id
        AND i.invoice_id = il.invoice_id
        AND il.account_number = g.account_number
        AND vendor_state IN ('AZ', 'CA', 'NV')
ORDER BY vendor_name ASC;