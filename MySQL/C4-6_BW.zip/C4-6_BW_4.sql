USE ap;

SELECT 
    vendor_name,
    CONCAT(vendor_city, ', ', vendor_state) AS Location,
    invoice_number,
    invoice_total
FROM
    vendors v
        LEFT JOIN
    invoices i ON v.vendor_id = i.vendor_id
ORDER BY invoice_number ASC , vendor_name ASC;
