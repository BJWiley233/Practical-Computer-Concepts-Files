USE ap;

SELECT 
    vendor_name, vendor_zip_code, 'Fresno' AS zone_location
FROM
    vendors v
WHERE
    vendor_city = 'Fresno' 
UNION SELECT 
    vendor_name, vendor_zip_code, 'LA area' AS zone_location
FROM
    vendors v
WHERE
    vendor_city IN ('Los Angeles' , 'Anaheim', 'Inglewood', 'Pasedona') 
UNION SELECT 
    vendor_name, vendor_zip_code, 'CA regional' AS zone_location
FROM
    vendors v
WHERE
    vendor_state = 'CA'
        AND vendor_city NOT IN ('Fresno' , 'Los Angeles',
        'Anaheim',
        'Inglewood',
        'Pasedona')
ORDER BY zone_location ASC, vendor_name ASC;
