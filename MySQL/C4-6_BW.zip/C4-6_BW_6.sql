USE ap;

SELECT 
    vendor_state,
    SUM(invoice_total) AS state_totals,
    ROUND(AVG(invoice_total), 2) AS state_avg,
    MAX(invoice_total) AS state_max,
    MIN(invoice_total) AS state_min,
    COUNT(invoice_id) AS state_inv_count
FROM
    vendors v
        JOIN
    invoices i ON v.vendor_id = i.vendor_id
WHERE
    invoice_total > 0
GROUP BY vendor_state
ORDER BY state_inv_count DESC;

