USE ap;

SELECT 
    v.vendor_id,
    SUM(invoice_total) AS invoice_gt,
    ROUND(AVG(invoice_total), 2) AS invoice_avg,
    COUNT(invoice_id) AS invoice_qty
FROM
    vendors v
        JOIN
    invoices i ON v.vendor_id = i.vendor_id
GROUP BY vendor_id
HAVING invoice_avg > 300
ORDER BY invoice_avg DESC;

