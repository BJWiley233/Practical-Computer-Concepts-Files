USE ap;

SELECT 
    vendor_city, 
    vendor_state, 
    SUM(invoice_total) AS inv_totals
FROM
    vendors v
        JOIN
    invoices i ON v.vendor_id = i.vendor_id
WHERE
    vendor_state IN ('CA' , 'TN')
GROUP BY vendor_city ASC , vendor_state WITH ROLLUP;
