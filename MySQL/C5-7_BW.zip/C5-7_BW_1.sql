USE ap;

INSERT INTO vendors_copy VALUES
(124, 'Waste Management', '23 E. Washington', NULL, 'Phoenix', 'AZ', '85001', '(602) 279-5641', 'Reeves', 'Bryant', 2, 521),
(125, 'Zip Printing', '412 N. Elm', NULL, 'Bakersfield', 'CA', '92659', '(559) 871-6564', 'Smith', 'Kathy', 1, 551),
(126, 'ACM Development', '8974 S. 17th Ave', 'Suit 200', 'Seattle', 'WA', '98102', '(206) 541-9112', 'Ayres', 'Ernesto', 4, 167)