USE ap;

SELECT 
    v.vendor_name,
    (SELECT 
            MAX(invoice_total)
        FROM
            invoices i
        WHERE
            v.vendor_id = i.vendor_id
        GROUP BY i.vendor_id) AS max_total
FROM
    vendors v
WHERE
    (SELECT 
            MAX(invoice_total)
        FROM
            invoices i
        WHERE
            v.vendor_id = i.vendor_id
        GROUP BY i.vendor_id) IS NOT NULL
ORDER BY max_total DESC;