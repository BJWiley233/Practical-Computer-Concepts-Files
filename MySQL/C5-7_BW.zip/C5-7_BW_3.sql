USE ap;

#SELECT * FROM invoices_copy
#WHERE invoice_date BETWEEN '2014-07-20' AND '2014-07-31';

UPDATE invoices_copy 
SET 
    payment_total = invoice_total - credit_total,
    payment_date = '2014-08-01'
WHERE
    invoice_date BETWEEN '2014-07-20' AND '2014-07-31'
        AND payment_date IS NULL;