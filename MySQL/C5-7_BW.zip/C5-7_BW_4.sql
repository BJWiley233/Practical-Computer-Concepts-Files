USE ap;

SELECT COUNT(vendor_id)
FROM vendors_copy;

DELETE FROM vendors_copy
WHERE vendor_id NOT IN (SELECT vendor_id
					FROM invoices_copy);
                    
SELECT COUNT(vendor_id)
FROM vendors_copy;
    
    
    