USE ap; 

SELECT v.vendor_id, invoice_number, invoice_date, invoice_total 
FROM vendors v JOIN invoices i
	ON v.vendor_id = i.vendor_id
WHERE vendor_state = 'CA'
ORDER BY vendor_id, invoice_date;