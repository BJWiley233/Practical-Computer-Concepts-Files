USE ap;

SELECT 
    invoice_number, invoice_date, invoice_total
FROM
    invoices i
WHERE
    invoice_total > (SELECT 
            AVG(invoice_total)
        FROM
            invoices i)
ORDER BY invoice_total DESC;                        



