USE ap;

SELECT 
    vendor_name, MAX(avg_total) AS max_bal_due
FROM
    (SELECT 
        v.vendor_name,
            i.vendor_id,
            AVG(invoice_total - payment_total - credit_total) AS avg_total
    FROM
        invoices i
    JOIN vendors v ON i.vendor_id = v.vendor_id
    GROUP BY v.vendor_id) t
GROUP BY vendor_name
ORDER BY max_bal_due DESC
LIMIT 3;