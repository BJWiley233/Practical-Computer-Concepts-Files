USE AP; 
CREATE TABLE vendors_copy AS 
SELECT * 
FROM vendors; 

USE AP; 
CREATE TABLE invoices_copy AS 
SELECT * 
FROM invoices 