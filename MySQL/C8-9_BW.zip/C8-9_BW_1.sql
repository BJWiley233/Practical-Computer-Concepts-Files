USE ap;

SELECT 
    vendor_name,
    UPPER(vendor_name) AS upper,
    CONCAT(LEFT(vendor_contact_first_name, 1),
            ' ',
            vendor_contact_last_name) AS v_name,
    RIGHT(vendor_phone, 4) AS v_phone
FROM
    vendors
WHERE
    vendor_phone IS NOT NULL;