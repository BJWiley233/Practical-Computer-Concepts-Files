USE ap;

SELECT 
    vendor_name,
    SUBSTRING(vendor_phone, - 8) AS no_ac_phone,
    SUBSTRING(vendor_name,
        LOCATE(' ', vendor_name) + 1) AS v_name_wo_first_name
FROM
    vendors
WHERE
    vendor_name REGEXP 'd';

