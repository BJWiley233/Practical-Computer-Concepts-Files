USE ap;

SELECT 
    v.vendor_name,
    invoice_number,
    invoice_date,
    DATE_FORMAT(invoice_date, '%W, %M %D, %Y') AS inv_date_formatted,
    DATE_FORMAT(invoice_date, '%M') AS inv_month,
    DATE_FORMAT(invoice_date, '%Y') AS inv_year,
    DATE_FORMAT(invoice_date, '%W') AS inv_day,
    DATE_ADD(invoice_date, INTERVAL 2 MONTH) AS inv_date_plus2,
    ABS(DATEDIFF(invoice_date, '2016-01-01')) AS inv_date_diff
FROM
    vendors v
        JOIN
    invoices i ON v.vendor_id = i.vendor_id
WHERE
    MONTH(invoice_date) = 6;

