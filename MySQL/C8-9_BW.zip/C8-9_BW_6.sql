USE ap;

SELECT 
    vendor_name,
    vendor_state,
    IF(vendor_state = 'CA',
        'California Vendor',
        'Non California vendor') AS `CA Vendor`,
    invoice_number,
    invoice_date,
    invoice_total,
    invoice_total - payment_total - credit_total AS bal_due,
    IF(invoice_total - payment_total - credit_total = 0,
        'PAID',
        'NOT PAID') AS pay_status
FROM
    vendors v
        JOIN
    invoices i ON v.vendor_id = i.vendor_id
ORDER BY vendor_name;