USE ap;

SELECT CONCAT(vendor_city, ', ', vendor_state) AS Location, 
	CONCAT(vendor_contact_first_name, ' ', vendor_contact_last_name) AS Contact
FROM vendors
ORDER BY vendor_contact_last_name ASC;