USE ap;

SELECT invoice_number, invoice_date, invoice_total,
	invoice_total - payment_total - credit_total AS balance_due,
    invoice_total * .15 AS late_fee
FROM invoices
WHERE invoice_total BETWEEN 300 AND 3000
ORDER BY invoice_total DESC;