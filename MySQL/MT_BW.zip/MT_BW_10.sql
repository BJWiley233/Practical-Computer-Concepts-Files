USE bbmsc;

SELECT 
    pos_date,
    pos_number,
    pos_customer,
    pos_payment,
    item,
    item_qty,
    ROUND(item_qty * (cost * (markup + 1)), 2) AS sub_total
FROM
    pos p
        JOIN
    item_pos ip ON p.p_id = ip.p_id
        JOIN
    inventory_items ii ON ip.ii_id = ii.ii_id
ORDER BY pos_date , pos_number , sub_total DESC;

SELECT 
    item,
    cost,
    markup,
    item_qty,
    pos_date,
    pos_number,
    ROUND(item_qty * cost, 2) AS tot_cost,
    ROUND(item_qty * (cost * (markup + 1)), 2) AS retail_tot,
    ROUND((item_qty * (cost * (markup + 1)) - (item_qty * cost)),
            2) AS profit
FROM
    pos p
        JOIN
    item_pos ip ON p.p_id = ip.p_id
        JOIN
    inventory_items ii ON ip.ii_id = ii.ii_id
ORDER BY pos_date , pos_number , profit DESC