USE bbmsc;

SELECT 
    item,
    sku,
    cost,
    is_name AS supplier_name,
    is_phone,
    CONCAT(is_contact_fn, ' ', is_contact_ln) as contact,
    is_address1,
    is_address2,
    is_city,
    is_state,
    is_zip
FROM
    inventory_items ii
        JOIN
    item_orders ito ON ii.ii_id = ito.ii_id
        JOIN
    item_supplier its ON ito.is_id = its.is_id
ORDER BY supplier_name;
    
