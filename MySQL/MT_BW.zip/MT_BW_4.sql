USE bbmsc;

SELECT 
    item, description, sku, tot_ordered
FROM
    (SELECT 
        ii_id, SUM(quantity) AS tot_ordered, COUNT(io_id) AS num_orders
    FROM
        item_orders ito
    WHERE
        order_date BETWEEN '2016-04-01' AND '2016-05-31'
    GROUP BY ii_id) am
        JOIN
    inventory_items ii ON am.ii_id = ii.ii_id
WHERE num_orders > 1;