USE bbmsc;

SELECT is_name, item, sku, cost, quantity, order_date, (cost * quantity) AS billed_amt
FROM item_supplier its JOIN item_orders ito 
	ON its.is_id = ito.is_id
    JOIN inventory_items ii
    ON ito.ii_id = ii.ii_id
WHERE order_date < "2016-05-01"
ORDER BY quantity ASC, billed_amt DESC;