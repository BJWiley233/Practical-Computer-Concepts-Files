USE bbmsc;

SELECT 
    is_name, SUM(quantity * cost) AS billed_tot
FROM
    item_supplier its
        JOIN
    item_orders ito ON its.is_id = ito.is_id
        JOIN
    inventory_items ii ON ito.ii_id = ii.ii_id
WHERE
    ito.is_id = (SELECT 
            is_id
        FROM
            item_supplier
        WHERE
            is_name LIKE 'Lakewood Paper%')
GROUP BY is_name;


