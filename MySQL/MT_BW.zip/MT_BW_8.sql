USE bbmsc;

SELECT 
    pos_date,
    pos_number,
    pos_customer,
    pos_payment,
    item,
    item_qty,
    ROUND(item_qty * (cost * (markup + 1)), 2) AS sub_total
FROM
    pos p
        JOIN
    item_pos ip ON p.p_id = ip.p_id
        JOIN
    inventory_items ii ON ip.ii_id = ii.ii_id
ORDER BY pos_date , pos_number , sub_total DESC;
