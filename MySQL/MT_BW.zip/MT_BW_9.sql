USE bbmsc;

SELECT 
    p.p_id,
    pos_customer,
    pos_payment,
    SUBSTRING(pos_customer,
        LOCATE(' ', pos_customer) + 1) AS l_name,
    SUM(ROUND(item_qty * (cost * (markup + 1)), 2)) AS pos_total
FROM
    pos p
        JOIN
    item_pos ip ON p.p_id = ip.p_id
        JOIN
    inventory_items ii ON ip.ii_id = ii.ii_id
WHERE
    pos_payment = 'Visa'
GROUP BY pos_customer
ORDER BY l_name;