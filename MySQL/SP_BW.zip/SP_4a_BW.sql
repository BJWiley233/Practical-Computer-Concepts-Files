Use trains;

CREATE OR REPLACE VIEW simple_schedule_train AS

SELECT 
    ts.train_id,
    ts.sequence,
    ts.station_start_id,
    s1.station_name AS station_start,
    ts.out_time,
    ts.station_end_id,
    s2.station_name AS station_end,
    ts.in_time,
    ts.ticket_cost
FROM
    train_schedule ts
        RIGHT JOIN
    stations s1 ON ts.station_start_id = s1.station_id
        RIGHT JOIN
    stations s2 ON ts.station_end_id = s2.station_id
ORDER BY ts.train_id , ts.sequence;

SELECT * from simple_schedule_train;


CREATE OR REPLACE VIEW simple_schedule_station AS

SELECT 
    ts.train_id,
    ts.sequence,
    ts.station_start_id,
    s1.station_name AS station_start,
    ts.out_time,
    ts.station_end_id,
    s2.station_name AS station_end,
    ts.in_time,
    ts.ticket_cost
FROM
    train_schedule ts
        RIGHT JOIN
    stations s1 ON ts.station_start_id = s1.station_id
        RIGHT JOIN
    stations s2 ON ts.station_end_id = s2.station_id
ORDER BY ts.station_start_id , ts.out_time;

SELECT * from simple_schedule_station