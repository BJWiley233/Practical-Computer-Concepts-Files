Use trains;

CREATE OR REPLACE VIEW highest_driver_hours AS
	SELECT 
		e.employee_id,
		CONCAT(first_name, ' ', last_name) full_name,
		position_title,
		SUM(TIMESTAMPDIFF(HOUR,
			start_time,
			end_time)) AS hours,
	YEAR(start_time) as year_worked,
	MONTH(start_time) as month_worked,
    WEEK(start_time) as week_worked
	FROM
		employees e
			JOIN
		employee_trains et ON e.employee_id = et.employee_id
	WHERE
		position_title LIKE '%engine%'
			AND e.employee_id IN (SELECT 
				e.employee_id
			FROM
				employee_trains e
			GROUP BY e.employee_id
			HAVING COUNT(*) > 5)
	GROUP BY e.employee_id
	ORDER BY hours DESC;
    
SELECT * from highest_driver_hours