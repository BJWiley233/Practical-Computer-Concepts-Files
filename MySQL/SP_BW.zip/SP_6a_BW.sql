Use trains;

CREATE OR REPLACE VIEW summary_passengers AS

SELECT CONCAT(p.first_name, " ", p.last_name) full_name, ps.passenger_id, 
	SUM(TIMESTAMPDIFF(HOUR,
					  ts.out_time,
                      ts.in_time)) AS hours_on_train,
	COUNT(trip_id) as num_trips,
    SUM(ps.ticket_cost) total_amt_paid,
    MONTH(ps.travel_date) month_traveled,
    YEAR(ps.travel_date) year_traveled
FROM passenger_schedule ps 
	JOIN passengers p 
		ON ps.passenger_id = p.passenger_id
	JOIN train_schedule ts
		ON ps.train_id = ts.train_id
		AND ps.sequence = ts.sequence
		AND ps.ticket_cost = ts.ticket_cost
GROUP BY ps.passenger_id, MONTH(ps.travel_date)
ORDER BY year_traveled ASC, year_traveled ASC, total_amt_paid DESC;

SELECT * FROM summary_passengers


       