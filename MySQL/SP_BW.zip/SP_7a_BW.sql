USE trains; 

 
DROP PROCEDURE IF EXISTS max_employee_passenger;
DELIMITER // 

CREATE PROCEDURE max_employee_passenger(IN driver_or_passengers VARCHAR(50),
						IN hours_or_payment VARCHAR(20),
                        IN month_ INT(12),
                        IN year_ INT(4)) 
BEGIN
DECLARE look_up_ep VARCHAR(50) DEFAULT driver_or_passengers;
DECLARE look_up_hr_pay VARCHAR(50) DEFAULT hours_or_payment;
DECLARE month_sel INT DEFAULT month_;
DECLARE year_sel INT DEFAULT year_;

IF look_up_ep LIKE "%driver%" AND look_up_hr_pay LIKE "%hour%" THEN
	SELECT full_name, month_worked, year_worked, max(hours), 
		CONCAT("Dear ", full_name, ",", " Thanks for your commitment...")
	FROM highest_driver_hours 
	WHERE month_worked = month_sel AND year_worked = year_sel;
ELSEIF look_up_ep LIKE "passenger%" THEN
	IF look_up_hr_pay LIKE "%hour%" THEN
		SELECT full_name, max(hours_on_train),
        CONCAT("Dear ", full_name, ",", " Thanks for your commitment...")
        FROM summary_passengers
        WHERE month_traveled = month_sel AND year_traveled = year_sel;
	ELSEIF look_up_hr_pay LIKE "%payment%" THEN
        SELECT full_name, max(total_amt_paid),
        CONCAT("Dear ", full_name, ",", " Thanks for your MONEY!...")
        FROM summary_passengers
        WHERE month_traveled = month_sel AND year_traveled = year_sel;
	END IF;
END IF;
END//


CALL max_employee_passenger("driver", "hour", 12, 2018);

CALL max_employee_passenger("passenger", "hour", 1, 2019);

CALL max_employee_passenger("passenger", "payment", 12, 2018);
                        