Use trains;
DROP FUNCTION IF EXISTS random_gen;

DROP FUNCTION IF EXISTS random_gen
DELIMITER //
CREATE FUNCTION random_gen(length INT)
RETURNS VARCHAR(15)
BEGIN
DECLARE int_length INT;
DECLARE i INT;
DECLARE finalint VARCHAR(15);

SET int_length = length;
SET i = 1;
SET finalint = '';

WHILE i < int_length + 1 DO
	SET finalint = CONCAT(finalint, FLOOR(RAND()*(9-0+1)));
    SET i = i + 1;
END WHILE;
RETURN(CAST(finalint AS UNSIGNED));
END//


SELECT random_gen(5);
